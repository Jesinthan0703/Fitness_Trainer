class Strings {
  static var stepOneTitle = "Farm Driving";
  static var stepOneContent = "There are all kinds of equipment to build your farm better harvest";
  static var stepTwoTitle = "Plant Growing";
  static var stepTwoContent = "Be part of the agriculture and gives your team the  power you need to do your best";
  static var stepThreeTitle = "Fast Harvesting";
  static var stepThreeContent = "Your will be proud to be part of agriculture and it’s harvest";
}