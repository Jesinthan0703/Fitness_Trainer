import 'package:carousel_slider/carousel_slider.dart';
import 'package:dab_fitness/main.dart';
import 'package:dab_fitness/welcome.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  Home() : super();
  @override
  State<StatefulWidget> createState() {
    return _Home();
  }
}

class _Home extends State<Home> {
  //
  CarouselSlider carouselSlider;
  int _current = 0;
  List imgList = [
    'https://images.unsplash.com/photo-1502117859338-fd9daa518a9a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1554321586-92083ba0a115?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1536679545597-c2e5e1946495?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1543922596-b3bbaba80649?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60',
    'https://images.unsplash.com/photo-1502943693086-33b5b1cfdf2f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=668&q=80'
  ];

  List<T> map<T>(List list, Function handler) {
    List<T> result = [];
    for (var i = 0; i < list.length; i++) {
      result.add(handler(i, list[i]));
    }
    return result;
  }
  int ci=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: ci,
        type: BottomNavigationBarType.fixed,
        backgroundColor:  Colors.black,
        unselectedItemColor: Colors.orange,
        selectedItemColor: Colors.red,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            title: Text('Home'),
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.search),
              title: Text('Appointments'),
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              title: Text('Settings'),
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.info),
              title: Text('About us'),
          )
        ],
          onTap: (index){
          setState(() {
            ci=index;
          });
    },
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient( begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [Colors.black,Colors.black]),),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 250,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage('assets/images/back1.jpg'),
                        fit: BoxFit.cover
                    ),
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10),
                      bottomRight: Radius.circular(10))
                ),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 10, top: 100, left: 10, right: 50),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:[
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.only(bottom:10, right: 105),
                          child: Text(" Hi Ajay!", style: TextStyle(fontSize: 50, color: Colors.yellow, fontFamily: "BillionDreams",fontWeight: FontWeight.w400,
                          ),
                          ),
                        ),
                      ),
                      Center(
                        child: Padding(
                          padding: const EdgeInsets.only(left:10),
                          child: Text("All progress takes place outside the comfort zone", style: TextStyle(fontSize: 20, color: Colors.orange, fontFamily: "Atmospheric",fontWeight: FontWeight.w400,
                          ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children:[
                    Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8.0, bottom:0.0 ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: InkWell(
                                  onTap: (){
                                  },
                                  child: Container(
                                    padding: EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                          colors: [Colors.red,Colors.orange,Colors.yellow]),
                                      borderRadius: BorderRadius.all(Radius.circular(15),),
                                    ),
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(top:8.0, bottom: 8.0),
                                          child: Text("In-person Training", style: TextStyle(color: Colors.black,fontFamily: "YesterdayDream", fontSize: 20,
                                          ),),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              ],
                          ),
                        )),
                    Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8.0, bottom:0.0 ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: InkWell(
                                  onTap: (){
                                  },
                                  child: Container(
                                    padding: EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                          colors: [Colors.red,Colors.orange,Colors.yellow]),
                                      borderRadius: BorderRadius.all(Radius.circular(15),),
                                    ),
                                    child: Column(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(top:8.0, bottom: 8.0),
                                          child: Text("Online Classes", style: TextStyle(color: Colors.black,fontFamily: "YesterdayDream", fontSize: 20,
                                          ),),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top:18.0),
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                    carouselSlider = CarouselSlider(
                    options: CarouselOptions(
                      height: 170.0,
                      initialPage: 0,
                      enlargeCenterPage: true,
                      autoPlay: true,
                      reverse: false,
                      enableInfiniteScroll: true,
                      autoPlayInterval: Duration(seconds: 5),
                      autoPlayAnimationDuration: Duration(milliseconds: 2000),
                      scrollDirection: Axis.horizontal,
                    ),
                    items: imgList.map((imgUrl) {
                      return Builder(
                        builder: (BuildContext context) {
                          return Container(
                            width: MediaQuery.of(context).size.width,
                            margin: EdgeInsets.symmetric(horizontal: 10.0),
                            decoration: BoxDecoration(
                              color: Colors.orange,
                            ),
                            child: Image.network(
                              imgUrl,
                              fit: BoxFit.fill,
                            ),
                          );
                        },
                      );
                    }).toList(),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  ]
                  )
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: InkWell(
                  onTap: (){
                    Navigator.push(context,
                        MaterialPageRoute(builder: (BuildContext context)=>WelcomePage()));
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          begin: Alignment.bottomLeft, end: Alignment.topRight,
                          colors: [Colors.black,Colors.black]),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top:8.0,bottom: 8.0),
                          child: Column(
                            children: [
                              Icon(Icons.play_circle_outline, color: Colors.orange, size: 30,),
                              Text("Offline Videos", style: TextStyle(color: Colors.orange, fontSize: 30,fontFamily: "YesterdayDream"),),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                height: 0,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10),
                      bottomRight: Radius.circular(10)),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}